#include<stdio.h>
int main()
{
    int x1,x2,sum;
    printf("enter the 1 no:\n");
    scanf("%d",&x1);
    printf("enter the 2 no:\n");
    scanf("%d",&x2);
    sum=x1+x2;
    printf("the result is %d\n",sum);

}